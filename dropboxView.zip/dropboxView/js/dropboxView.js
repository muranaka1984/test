$(function(){
  var dropboxSlideBtn = $('.dropboxSlide li p');
  var current;
  var currentImg;
  var iFirst = 0;
  var iLast = $('.dropboxSlide li').length - 1;
  var img = new Image();

  $('.dropboxSlide').wrap('<div class="dropboxViewWrap"></div>');
  $('.dropboxViewWrap').append('<div class="dropboxView">' +
  	'<p class="icon back"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 12l9-8v6h15v4h-15v6z"/></svg></p>' +
    '<p class="icon next"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 3.795l2.995-2.98 11.132 11.185-11.132 11.186-2.995-2.981 8.167-8.205-8.167-8.205zm18.04 8.205l-8.167 8.205 2.995 2.98 11.132-11.185-11.132-11.186-2.995 2.98 8.167 8.206z"/></svg></p>' +
    '<p class="icon prev"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 3.795l2.995-2.98 11.132 11.185-11.132 11.186-2.995-2.981 8.167-8.205-8.167-8.205zm18.04 8.205l-8.167 8.205 2.995 2.98 11.132-11.185-11.132-11.186-2.995 2.98 8.167 8.206z"/></svg></p>' +
  	'<div class="dropboxViewCell"><img src="" class="dropboxSlideItem"></div>' +
  	'</div><div class="dropboxViewLoader"><img src="img/gif-load.gif"></div>');

  $(dropboxSlideBtn).click(function () {
    $('.dropboxView').addClass('active');
    $('.dropboxViewLoader').addClass('active');
    currentImg = $(this).attr('title');
    img.src = currentImg;
    img.onload = function() {
      $('.dropboxViewLoader').removeClass('active');
      $('.dropboxSlideItem').attr('src',currentImg);
    }
    current = $(this).parent('li').index();
  });

  $('.dropboxView .back').click(function () {
    $('.dropboxSlideItem').attr('src','');
    $('.dropboxView').removeClass('active');
  });

  $('.dropboxView .next').click(function () {
    NextImg();
  });

  $('.dropboxView .prev').click(function () {
    PrevImg();
  });

  $(window).keyup(function(e){
  	if(e.keyCode == 39){
  		NextImg();
  	}
  });

  $(window).keyup(function(e){
  	if(e.keyCode == 37){
  		PrevImg();
  	}
  });

  function NextImg() {
     if(current < iLast){
      $('.dropboxViewLoader').addClass('active');
      current++;
      currentImg = $('.dropboxSlide li').eq(current).find('p').attr('title');
      img.src = currentImg;
      img.onload = function() {
        // console.log("COMPLETED");
        $('.dropboxViewLoader').removeClass('active');
        $('.dropboxSlideItem').attr('src',currentImg);
      }
    }
  }

  function PrevImg() {
     if(current > iFirst){
      $('.dropboxViewLoader').addClass('active');
      current--;
      currentImg = $('.dropboxSlide li').eq(current).find('p').attr('title');
      img.src = currentImg;
      img.onload = function() {
        $('.dropboxViewLoader').removeClass('active');
        $('.dropboxSlideItem').attr('src',currentImg);
      }
    }
  }



});